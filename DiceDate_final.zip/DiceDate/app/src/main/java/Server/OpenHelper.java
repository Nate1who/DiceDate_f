package Server;

import static Server.DataBase.DATABASE_NAME;
import static Server.DataBase.DATABASE_VERSION;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import domain.User;

public class OpenHelper extends SQLiteOpenHelper {

    private static final String TABLE_USER = "User";
    private static final String USER_COLUMN_ID = "id";
    private static final String USER_COLUMN_NAME = "name";
    private static final String USER_COLUMN_PASSWORD = "password";

    public OpenHelper(@Nullable Context context) {
        super(context,  DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String query = "CREATE TABLE " + TABLE_USER + "(" + USER_COLUMN_ID +
                " INTEGER PRIMARY KEY AUTOINCREMENT, " + USER_COLUMN_NAME + " TEXT NOT NULL, "
                + USER_COLUMN_PASSWORD + " TEXT NOT NULL);";
        sqLiteDatabase.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String query = "DROP TABLE IF EXISTS " + TABLE_USER;
        sqLiteDatabase.execSQL(query);
        onCreate(sqLiteDatabase);
    }

    public long addUser(User user) {
        SQLiteDatabase database = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USER_COLUMN_NAME, user.getName());
        contentValues.put(USER_COLUMN_PASSWORD, user.getPassword());
        long id = database.insert(TABLE_USER, null, contentValues);
        database.close();
        return id;
    }

    public int updateUser(User user) {
        SQLiteDatabase database = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USER_COLUMN_NAME, user.getName());
        contentValues.put(USER_COLUMN_PASSWORD, user.getPassword());
        int rowsAffected = database.update(TABLE_USER, contentValues, USER_COLUMN_ID + " = ?",
                new String[]{String.valueOf(user.getId())});
        database.close();
        return rowsAffected;
    }

    public int deleteUser(long id) {
        SQLiteDatabase database = getWritableDatabase();
        int rowsAffected = database.delete(TABLE_USER, USER_COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
        database.close();
        return rowsAffected;
    }

    public List<User> selectAllUsers() {
        SQLiteDatabase database = getReadableDatabase();
        List<User> users = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = database.query(TABLE_USER,
                    new String[]{USER_COLUMN_ID, USER_COLUMN_NAME, USER_COLUMN_PASSWORD},
                    null, null, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    long id = cursor.getLong(cursor.getColumnIndexOrThrow(USER_COLUMN_ID));
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(USER_COLUMN_NAME));
                    String password = cursor.getString(cursor.getColumnIndexOrThrow(USER_COLUMN_PASSWORD));
                    User user = new User(id, name, password);
                    users.add(user);
                } while (cursor.moveToNext());
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            database.close();
        }
        return users;
    }

    public List<User> selectUsersByName(String name) {
        SQLiteDatabase database = getReadableDatabase();
        List<User> users = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = database.query(TABLE_USER,
                    new String[]{USER_COLUMN_ID, USER_COLUMN_NAME, USER_COLUMN_PASSWORD},
                    USER_COLUMN_NAME + " = ?", new String[]{name}, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    long id = cursor.getLong(cursor.getColumnIndexOrThrow(USER_COLUMN_ID));
                    String userName = cursor.getString(cursor.getColumnIndexOrThrow(USER_COLUMN_NAME));
                    String password = cursor.getString(cursor.getColumnIndexOrThrow(USER_COLUMN_PASSWORD));
                    User user = new User(id, userName, password);
                    users.add(user);
                } while (cursor.moveToNext());
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            database.close();
        }
        return users;
    }
}