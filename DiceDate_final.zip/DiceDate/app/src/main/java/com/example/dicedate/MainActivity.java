package com.example.dicedate;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;


import Server.DataBase;

public class MainActivity extends AppCompatActivity {
    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "user_prefs";
    private static final String KEY_EMAIL = "email";
    private DataBase dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeComponents();
        setupNavigationAfterViewsReady();
    }

    private void initializeComponents() {
        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);
        dbHelper = new DataBase(this);

        // Для отладки (удалить в продакшене)
    }

    private void setupNavigationAfterViewsReady() {
        final View contentView = findViewById(android.R.id.content);
        contentView.post(() -> {
            try {
                NavController navController = Navigation.findNavController(this, R.id.fragmentContainerView);
                checkUserAuthorization(navController);
            } catch (Exception e) {
                Toast.makeText(this, "Ошибка инициализации навигации", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    private void checkUserAuthorization(NavController navController) {
        try {
            if (sharedPreferences.contains(KEY_EMAIL)) {
                String email = sharedPreferences.getString(KEY_EMAIL, "");
                if (dbHelper.emailExists(email)) {
                    navController.navigate(R.id.main2);
                } else {
                    clearInvalidSession();
                }
            }
        } catch (Exception e) {
            clearInvalidSession();
        }
    }

    private void clearInvalidSession() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(KEY_EMAIL);
        editor.apply();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isFinishing()) {
            dbHelper.close();
        }
    }

    @Override
    protected void onDestroy() {
        if (!isFinishing()) {
            dbHelper.close();
        }
        super.onDestroy();
    }

    // Только для отладки (удалить в финальной версии)
    private void testDatabaseOperations() {
        try {
            // Тест регистрации
            boolean isRegistered = dbHelper.addUser("test@example.com", "test123");
            Toast.makeText(this, isRegistered ? "Тест регистрации: УСПЕХ" : "Тест регистрации: ОШИБКА",
                    Toast.LENGTH_SHORT).show();

            // Тест авторизации
            boolean isValid = dbHelper.checkUser("test@example.com", "test123");
            Toast.makeText(this, isValid ? "Тест входа: УСПЕХ" : "Тест входа: ОШИБКА",
                    Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this, "Тест БД: ОШИБКА - " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}