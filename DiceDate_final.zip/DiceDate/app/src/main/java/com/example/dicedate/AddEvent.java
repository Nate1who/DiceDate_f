package com.example.dicedate;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatButton;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Date;

public class AddEvent extends Fragment {

    Button add_button;

    EditText title_of_game_text, description_text, date_of_game_text;
    EditText time_of_game_text;

    FirebaseDatabase database = FirebaseDatabase.getInstance("https://dicedate-a94ce-default-rtdb.firebaseio.com/");

    DatabaseReference gamesRef = database.getReference("Games/");
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_event, container, false);

        title_of_game_text =  view.findViewById(R.id.Event_Name);
        time_of_game_text = view.findViewById(R.id.Event_Time);
        add_button = view.findViewById(R.id.AddEvent_Create);
        date_of_game_text = view.findViewById(R.id.date_of_game);
        description_text = view.findViewById(R.id.description);

        // Обработка всех кнопок в одном методе
        setupButtons(view);
        setOnClickListeners(view);

        return view;
    }

    private void setupButtons(View view) {
        // Кнопка создания события
        AppCompatButton createButton = view.findViewById(R.id.AddEvent_Create);
        if (createButton != null) {
            createButton.setOnClickListener(v -> {
                Navigation.findNavController(view).navigate(R.id.NavigationToAddEvent_AddEvent);
            });
        }

        // Кнопка настроек
        AppCompatButton settingsButton = view.findViewById(R.id.AddEvent_Setting);
        if (settingsButton != null) {
            settingsButton.setOnClickListener(v -> {
                Navigation.findNavController(view).navigate(R.id.NavigationToSetting_AddEvent);
            });
        }

        // Кнопка игр
        AppCompatButton gamesButton = view.findViewById(R.id.AddEvent_Games);
        if (gamesButton != null) {
            gamesButton.setOnClickListener(v -> {
                Navigation.findNavController(view).navigate(R.id.NavigationToMain_AddEvent);
            });
        }
    }

    public AddEvent() {
        // Пустой конструктор
    }

    private void setOnClickListeners(View view){
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (title_of_game_text.getText().toString().isEmpty() || time_of_game_text.getText().toString().isEmpty()){
                    Toast.makeText(getContext(), "Поля не могут быть пустыми!", Toast.LENGTH_SHORT).show();
                    return;
                }
                long timestamp = getTimeStamp(date_of_game_text.getText().toString(), time_of_game_text.getText().toString());
                if (timestamp== -1) {
                    Toast.makeText(getContext(), "Введите корректную дату и время!", Toast.LENGTH_SHORT).show();
                    return;
                }
                Game game = new Game(title_of_game_text.getText().toString(),
                        description_text.getText().toString(),
                        timestamp
                );
                DatabaseReference gameRef = gamesRef.push();
                gameRef.setValue(game);
                Navigation.findNavController(view).navigate(R.id.NavigationToMain_AddEvent);
            }
        });

    }


    private long getTimeStamp (String date, String time){
        try{
            String[] dateData = date.split("\\.");
            String[] timeData = time.split(":");
            if (dateData.length < 3 || timeData.length < 2){
                return -1;
            }
            Date dateObject = new Date(
                    Integer.parseInt(dateData[2]) - 1900, Integer.parseInt(dateData[1]) - 1, Integer.parseInt(dateData[0]),
                    Integer.parseInt(timeData[0]), Integer.parseInt(timeData[1])
            );
            return dateObject.getTime();
        }catch (Exception ex){
            return  -1;
        }
    }


}