package com.example.dicedate;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.Date;


public class GameDetails extends Fragment {

    TextView game_title_text, game_description_text, game_date_text;

    public static Game currentGame;

    public GameDetails() {
        // Required empty public constructor
    }


    private void init(View view){
        game_title_text = view.findViewById(R.id.game_title_text);
        game_description_text = view.findViewById(R.id.game_descriprion_text);
        game_date_text = view.findViewById(R.id.game_date_text);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);
        setValues();
    }

        @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_game_details, container, false);
    }

    private void setValues(){
        game_title_text.setText(currentGame.title);
        game_description_text.setText(currentGame.description);
        Date date = new Date(currentGame.time);
        game_date_text.setText(getStringFromDate(date));

    }

    private String getStringFromDate(Date date) {
        String result = "";
        int hours = date.getHours();
        int minutes = date.getMinutes();
        int day = date.getDate();
        int month = date.getMonth() + 1;
        int year = date.getYear() + 1900;
        if (String.valueOf(hours).length() == 1) result += "0";
        result += hours + ":";
        if (String.valueOf(minutes).length() == 1) result += "0";
        result += minutes + " ";
        if (String.valueOf(day).length() == 1) result += "0";
        result += day + ".";
        if (String.valueOf(month).length() == 1) result += "0";
        result += month + ".";
        if (String.valueOf(year).length() == 1) result += "0";
        result += year;
        return result;
    }
}