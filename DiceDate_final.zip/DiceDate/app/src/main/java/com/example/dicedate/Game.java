package com.example.dicedate;

public class Game {
    public String title;
    public String description;
    public long time;

    public Game(String title,String description ,long time) {
        this.title = title;
        this.time = time;
        this.description = description;
    }

    public  Game(){}

}
