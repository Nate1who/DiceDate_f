package com.example.dicedate;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Date;

public class GamesAdapter extends RecyclerView.Adapter<GamesViewHolder> {
    Context context;
    LayoutInflater inflater;

    ArrayList<Game> gamesList = new ArrayList<>();

    View view;

    public GamesAdapter(Context context, ArrayList<Game> gamesList, View view) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.gamesList = gamesList;
        this.view = view;
    }

    @NonNull
    @Override
    public GamesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.game_item, parent, false);
        return new GamesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GamesViewHolder holder, int position) {
        Game game = gamesList.get(position);
        holder.title.setText(game.title);
        Date date = new Date(game.time);
        holder.time.setText(getStringFromDate(date));
        holder.game_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GameDetails.currentGame = game;
                Navigation.findNavController(view).navigate(R.id.NavigationToGameDetails_Main);

            }
        });
    }

    @Override
    public int getItemCount() {
        return gamesList.size();
    }

    private String getStringFromDate(Date date) {
        String result = "";
        int hours = date.getHours();
        int minutes = date.getMinutes();
        int day = date.getDate();
        int month = date.getMonth() + 1;
        int year = date.getYear() + 1900;
        if (String.valueOf(hours).length() == 1) result += "0";
        result += hours + ":";
        if (String.valueOf(minutes).length() == 1) result += "0";
        result += minutes + " ";
        if (String.valueOf(day).length() == 1) result += "0";
        result += day + ".";
        if (String.valueOf(month).length() == 1) result += "0";
        result += month + ".";
        if (String.valueOf(year).length() == 1) result += "0";
        result += year;
        return result;
    }
}


class GamesViewHolder extends RecyclerView.ViewHolder {

    TextView title, time;

    CardView game_card;

    public GamesViewHolder(@NonNull View itemView) {
        super(itemView);
        title = itemView.findViewById(R.id.game_title);
        time = itemView.findViewById(R.id.game_time);
        game_card = itemView.findViewById(R.id.game_card);
    }
}
