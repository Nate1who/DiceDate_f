package com.example.dicedate;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import Server.DataBase;
import Server.OpenHelper;
import domain.User;

public class Registration extends Fragment {
    private EditText editTextInputLogin, editTextInputPassword;
    private Button buttonRegistration, buttonGoToEnter;
    private OpenHelper dbHelper;
    private FirebaseAuth mAuth;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_registration, container, false);

        editTextInputLogin = view.findViewById(R.id.editTextInput_login);
        editTextInputPassword = view.findViewById(R.id.editTextInput_password);
        buttonRegistration = view.findViewById(R.id.button_registration);
        buttonGoToEnter = view.findViewById(R.id.button_registration_go_to_enter);
        mAuth = FirebaseAuth.getInstance();

        dbHelper = new OpenHelper(requireContext());

        return view;
    }


    private void setOnClickListeners(View view) {
        buttonRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextInputLogin.getText().toString().isEmpty() || editTextInputPassword.getText().toString().isEmpty()) {
                    Toast.makeText(getContext(), "Поля не могут быть пустыми!", Toast.LENGTH_SHORT).show();
                    return;
                }
                mAuth.createUserWithEmailAndPassword(editTextInputLogin.getText().toString(), editTextInputPassword.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Navigation.findNavController(view).navigate(R.id.NavigationToMain_Registration);
                        } else {
                            Toast.makeText(getContext(), "Произошла ошибка!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

//        buttonRegistration.setOnClickListener(v -> {
//            String email = editTextInputLogin.getText().toString().trim();
//            String password = editTextInputPassword.getText().toString().trim();
//
//            if (validateInput(email, password)) {
//                registerUser(email, password, view);
//            }
//        });
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            Navigation.findNavController(view).navigate(R.id.NavigationToMain_Registration);
        }

        setOnClickListeners(view);

        buttonGoToEnter.setOnClickListener(v -> {
            Navigation.findNavController(view).navigate(R.id.NavigationToEnter);
        });
    }


    private boolean validateInput(String email, String password) {
        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextInputLogin.setError("Введите корректный email");
            return false;
        }
        if (password.isEmpty() || password.length() < 6) {
            editTextInputPassword.setError("Пароль должен быть не менее 6 символов");
            return false;
        }
        return true;
    }

    private void registerUser(String email, String password, View view) {


        // 2. Сохраняем в SQLite
        User newUser = new User(email, password);
        long userId = dbHelper.addUser(newUser);

        if (userId != -1) {
            // 3. Сохраняем в SharedPreferences
            SharedPreferences sharedPrefs = requireContext().getSharedPreferences(
                    "user_prefs", Context.MODE_PRIVATE);

            SharedPreferences.Editor editor = sharedPrefs.edit();
            editor.putString("email", email);
            editor.putBoolean("is_logged_in", true);
            if (!editor.commit()) {
                Log.e("Registration", "Failed to save preferences");
            }

            Toast.makeText(requireContext(), "Регистрация успешна!",
                    Toast.LENGTH_SHORT).show();
            Navigation.findNavController(view).navigate(R.id.NavigationToMain_Registration);
        } else {
            Toast.makeText(requireContext(), "Ошибка регистрации",
                    Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}