package domain;

public class User {
    private long id;
    private String name;
    private String password;

    // Пустой конструктор (может быть полезен для некоторых фреймворков)
    public User() {
    }

    // Конструктор с ID
    public User(long id, String name, String password) {
        this.id = id;
        this.name = name;
        this.password = password;
    }

    // Конструктор без ID (для создания новых пользователей)
    public User(String name, String password) {
        this.name = name;
        this.password = password;
    }

    // Геттеры и сеттеры
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}