package fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.dicedate.R;

public class CreateNewPassword extends Fragment {

    private EditText editTextNewPassword, editTextConfirmPassword;
    private SharedPreferences sharedPreferences;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Надуваем макет только один раз
        View view = inflater.inflate(R.layout.fragment_create_new_password, container, false);

        // Инициализация элементов
        editTextNewPassword = view.findViewById(R.id.editTextInput_login);
        editTextConfirmPassword = view.findViewById(R.id.editTextInput_password);

        // Получаем SharedPreferences
        sharedPreferences = requireActivity().getSharedPreferences("user_prefs", 0);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Обработка кнопки подтверждения
        view.findViewById(R.id.forgetPassword_to_home).setOnClickListener(v -> {
            String newPassword = editTextNewPassword.getText().toString();
            String confirmPassword = editTextConfirmPassword.getText().toString();

            if (validatePasswords(newPassword, confirmPassword)) {
                // Обновляем пароль в SharedPreferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("password", newPassword);
                editor.apply();

                Toast.makeText(requireContext(), "Пароль успешно изменен", Toast.LENGTH_SHORT).show();
                Navigation.findNavController(view).navigate(R.id.NavigationToMain_CreateNewPassword);
            }
        });
    }

    private boolean validatePasswords(String newPassword, String confirmPassword) {
        if (newPassword.isEmpty() || newPassword.length() < 6) {
            editTextNewPassword.setError("Пароль должен быть не менее 6 символов");
            return false;
        }

        if (!newPassword.equals(confirmPassword)) {
            editTextConfirmPassword.setError("Пароли не совпадают");
            return false;
        }

        return true;
    }
}