package fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.NavOptions;
import androidx.navigation.Navigation;

import com.example.dicedate.R;
import com.google.firebase.auth.FirebaseAuth;

public class LeaveAuthorization extends Fragment {

    private FirebaseAuth mAuth;
    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "user_prefs";

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences = requireActivity().getSharedPreferences(SHARED_PREF_NAME, 0);
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_leave_authorization, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mAuth = FirebaseAuth.getInstance();

        // Инициализация всех кнопок
        AppCompatButton logoutButton = view.findViewById(R.id.button_logout);
        AppCompatButton createButton = view.findViewById(R.id.Logout_Create);
        AppCompatButton settingsButton = view.findViewById(R.id.Logout_Setting);
        AppCompatButton gamesButton = view.findViewById(R.id.Logout_Games);

        // Обработка кнопки выхода
        if (logoutButton != null) {
            logoutButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mAuth.signOut();
                    Navigation.findNavController(view).navigate(R.id.NavigationToRegistrationn_Setting);
                }
            });
        }

        // Обработка остальных кнопок
        setupNavigationButtons(view, createButton, settingsButton, gamesButton);
    }

    private void setupNavigationButtons(View view,
                                        AppCompatButton createButton,
                                        AppCompatButton settingsButton,
                                        AppCompatButton gamesButton) {
        try {
            NavController navController = Navigation.findNavController(view);

            if (createButton != null) {
                createButton.setOnClickListener(v ->
                        navController.navigate(R.id.NavigationToRegistrationn_Setting));
            }

            if (settingsButton != null) {
                settingsButton.setOnClickListener(v ->
                        navController.navigate(R.id.NavigationToSetting_Setting));
            }

            if (gamesButton != null) {
                gamesButton.setOnClickListener(v ->
                        navController.navigate(R.id.NavigationToMain_Setting));
            }
        } catch (Exception e) {
            Toast.makeText(requireContext(), "Ошибка навигации", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void clearAuthData() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }

    private void navigateToRegistration(View view) {
        try {
            NavController navController = Navigation.findNavController(view);
            NavOptions navOptions = new NavOptions.Builder()
                    .setPopUpTo(R.id.leaveAuthorization, true)
                    .build();

            navController.navigate(
                    R.id.NavigationToRegistrationn_Setting,
                    null,
                    navOptions
            );
        } catch (Exception e) {
            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragmentContainerView, new Registration())
                    .commit();
            throw new RuntimeException("Navigation failed", e);
        }
    }
}