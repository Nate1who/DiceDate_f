package fragment;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.AppCompatButton;

import com.example.dicedate.R;

public class ForgetPassword extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_forget_password, container, false);

        // Обработка кнопки регистрации (если она есть в layout)
        AppCompatButton regButton = view.findViewById(R.id.hello_to_Create_New_Password);
        if (regButton != null) {
            regButton.setOnClickListener(v -> {
                Navigation.findNavController(view).navigate(R.id.NavigationToCreateNewPassword);
            });
        }

        return view;
    }

    public ForgetPassword() {
        // Пустой конструктор
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}