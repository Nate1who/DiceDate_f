package fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import domain.Game;
import adapter.GamesAdapter;
import com.example.dicedate.R;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Date;

public class Main extends Fragment {

    RecyclerView games_recycler;
    Button add_btn;

    GamesAdapter adapter;

    ArrayList<Game> gamesList = new ArrayList<>();

    FirebaseDatabase database = FirebaseDatabase.getInstance("https://dicedate-a94ce-default-rtdb.firebaseio.com/");

    DatabaseReference gamesRef = database.getReference("Games/");


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);

        // Обработка всех кнопок в одном методе
        setupButtons(view);
        gamesList.clear();
        games_recycler = view.findViewById(R.id.Main_ViewGames);
        add_btn = view.findViewById(R.id.Main_Create);
        adapter = new GamesAdapter(getContext(), gamesList, view);
        games_recycler.setAdapter(adapter);
        games_recycler.setLayoutManager(new LinearLayoutManager(getContext()));
        setOnClickListeners();
        addEventListener();

        return view;
    }

    private void addEventListener() {
        gamesRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Game game = snapshot.getValue(Game.class);
                gamesList.add(game);
                adapter.notifyItemInserted(gamesList.size());
                Date nowDate = new Date();
                if (nowDate.getTime() > game.time){
                    DatabaseReference removingEvent = snapshot.getRef();
                    removingEvent.removeValue();
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                Game game = snapshot.getValue(Game.class);
                if (game == null) return;;
                for (int i = 0; i < gamesList.size(); i++){
                    if (gamesList.get(i).time == game.time){
                        gamesList.remove(i);
                        adapter.notifyItemInserted(i);
                        break;
                    }
                }
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void setOnClickListeners(){
        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                gamesList.add(new Game("Game", "19:00"));
//                adapter.notifyItemInserted(gamesList.size());
                Navigation.findNavController(view).navigate(R.id.NavigationToAddEvent_main2);
            }
        });
    }

    private void setupButtons(View view) {
        // Кнопка создания события
        AppCompatButton createButton = view.findViewById(R.id.Main_Create);
        if (createButton != null) {
            createButton.setOnClickListener(v -> {
                Navigation.findNavController(view).navigate(R.id.NavigationToAddEvent_main2);
            });
        }

        // Кнопка настроек
        AppCompatButton settingsButton = view.findViewById(R.id.Main_Setting);
        if (settingsButton != null) {
            settingsButton.setOnClickListener(v -> {
                Navigation.findNavController(view).navigate(R.id.NavigationToSetting_main);
            });
        }

        // Кнопка игр
        AppCompatButton gamesButton = view.findViewById(R.id.Main_Games);
        if (gamesButton != null) {
            gamesButton.setOnClickListener(v -> {
                Navigation.findNavController(view).navigate(R.id.NavigationToMain_main);
            });
        }
    }

    public Main() {
        // Пустой конструктор
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}