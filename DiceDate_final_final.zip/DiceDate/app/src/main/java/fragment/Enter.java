package fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.dicedate.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Enter extends Fragment {

    private EditText editTextInputLogin, editTextInputPassword;
    private Button buttonForgetPassword, buttonGoToHome;
    private SharedPreferences sharedPreferences;

    private FirebaseAuth mAuth;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Используем простой inflate без binding
        View view = inflater.inflate(R.layout.fragment_enter, container, false);

        // Инициализация элементов
        editTextInputLogin = view.findViewById(R.id.editTextInput_login);
        editTextInputPassword = view.findViewById(R.id.editTextInput_password);
//        buttonForgetPassword = view.findViewById(R.id.hello_to_forget_password);
        buttonGoToHome = view.findViewById(R.id.hello_to_registration);
        mAuth = FirebaseAuth.getInstance();

        // Получаем SharedPreferences
        sharedPreferences = requireActivity().getSharedPreferences("user_prefs", 0);

        return view;
    }

    private void setOnClickListeners(View view) {
        buttonGoToHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextInputLogin.getText().toString().isEmpty() || editTextInputPassword.getText().toString().isEmpty()) {
                    Toast.makeText(getContext(), "Поля не могут быть пустыми!", Toast.LENGTH_SHORT).show();
                    return;
                }
                mAuth.signInWithEmailAndPassword(editTextInputLogin.getText().toString(), editTextInputPassword.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Navigation.findNavController(view).navigate(R.id.NavigationToMain_Enter);
                        } else {
                            Toast.makeText(getContext(), "Произошла ошибка!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

//        buttonGoToHome.setOnClickListener(v -> {
//            String email = editTextInputLogin.getText().toString();
//            String password = editTextInputPassword.getText().toString();
//
//            if(validateInput(email, password)) {
//                SharedPreferences.Editor editor = sharedPreferences.edit();
//                editor.putString("email", email);
//                editor.putString("password", password);
//                editor.apply();
//
//                Navigation.findNavController(view).navigate(R.id.NavigationToMain_Enter);
//            }
//        });

//        buttonForgetPassword.setOnClickListener(v -> {
//            Navigation.findNavController(view).navigate(R.id.NavigationToForgetPassword);
//        });

        setOnClickListeners(view);
    }

    private boolean validateInput(String email, String password) {
        if(email.isEmpty()) {
            editTextInputLogin.setError("Введите email");
            return false;
        }
        if(password.isEmpty() || password.length() < 6) {
            editTextInputPassword.setError("Пароль должен быть не менее 6 символов");
            return false;
        }
        return true;
    }
}